import { useCallback, useEffect, useState } from "react";
import { Brain, Moon, Sun, Github } from "lucide-react";
import { InputForm } from "@/components/InputForm";
import { LoadingState } from "@/components/LoadingState";
import { ErrorState } from "@/components/ErrorState";
import { StudyView } from "@/components/StudyView";
import { SessionHistory } from "@/components/SessionHistory";
import { useGenerate } from "@/hooks/useGenerate";
import { useSessions } from "@/hooks/useSessions";
import { useTheme } from "@/hooks/useTheme";
import type { SavedSession } from "@/lib/supabase";

function App() {
  const { theme, toggleTheme } = useTheme();
  const { status, content, sessionId, error, generate, cancel, loadContent } = useGenerate();
  const { sessions, loading: sessionsLoading, remove, loadFromSession } = useSessions();
  const [lastTopic, setLastTopic] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleGenerate = useCallback(
    (topic: string) => {
      setLastTopic(topic);
      generate(topic);
    },
    [generate],
  );

  const handleRetry = useCallback(() => {
    if (lastTopic) {
      generate(lastTopic);
    }
  }, [lastTopic, generate]);

  const handleReset = useCallback(() => {
    cancel();
    setLastTopic(null);
  }, [cancel]);

  const handleNew = useCallback(() => {
    handleReset();
  }, [handleReset]);

  const handleSelectSession = useCallback(
    (session: SavedSession) => {
      const { content: sessionContent, sessionId: sid } = loadFromSession(session);
      loadContent(sessionContent, sid);
      setLastTopic(session.topic);
      setSidebarOpen(false);
    },
    [loadFromSession, loadContent],
  );

  const handleDeleteSession = useCallback(
    async (id: string) => {
      await remove(id);
      if (id === sessionId) {
        handleReset();
      }
    },
    [remove, sessionId, handleReset],
  );

  // Close sidebar on escape
  useEffect(() => {
    if (!sidebarOpen) return;
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === "Escape") setSidebarOpen(false);
    };
    window.addEventListener("keydown", handleEsc);
    return () => window.removeEventListener("keydown", handleEsc);
  }, [sidebarOpen]);

  const showHero = status === "idle" && !content;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors">
      {/* Header */}
      <header className="sticky top-0 z-30 backdrop-blur-md bg-white/80 dark:bg-slate-950/80 border-b border-slate-200 dark:border-slate-800">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-teal-600 shadow-sm">
              <Brain className="h-5 w-5 text-white" />
            </div>
            <div>
              <h1 className="text-base font-bold leading-tight">StudyForge</h1>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-tight hidden sm:block">
                AI-powered flashcards & quizzes
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {sessions.length > 0 && (
              <button
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden inline-flex items-center justify-center rounded-lg p-2 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                aria-label="Open history"
              >
                <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              </button>
            )}
            <button
              onClick={toggleTheme}
              className="inline-flex items-center justify-center rounded-lg p-2 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              aria-label="Toggle dark mode"
            >
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 sm:px-6 py-6 sm:py-10">
        <div className="flex gap-8">
          {/* Sidebar — desktop */}
          <aside className="hidden lg:block w-72 flex-shrink-0">
            <div className="sticky top-20">
              <SessionHistory
                sessions={sessions}
                loading={sessionsLoading}
                onSelect={handleSelectSession}
                onDelete={handleDeleteSession}
                activeSessionId={sessionId}
              />
            </div>
          </aside>

          {/* Sidebar — mobile drawer */}
          {sidebarOpen && (
            <>
              <div
                className="fixed inset-0 z-40 bg-black/40 lg:hidden"
                onClick={() => setSidebarOpen(false)}
              />
              <aside className="fixed left-0 top-0 bottom-0 z-50 w-80 max-w-[85vw] bg-white dark:bg-slate-900 shadow-2xl lg:hidden overflow-y-auto p-4 pt-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-sm font-semibold text-slate-600 dark:text-slate-400">History</h2>
                  <button
                    onClick={() => setSidebarOpen(false)}
                    className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
                    aria-label="Close"
                  >
                    <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
                <SessionHistory
                  sessions={sessions}
                  loading={sessionsLoading}
                  onSelect={handleSelectSession}
                  onDelete={handleDeleteSession}
                  activeSessionId={sessionId}
                />
              </aside>
            </>
          )}

          {/* Main content */}
          <div className="flex-1 min-w-0">
            {showHero && (
              <div className="text-center mb-8">
                <h2 className="text-2xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
                  Turn any topic into an
                  <span className="text-teal-600 dark:text-teal-400"> interactive study set</span>
                </h2>
                <p className="mt-3 text-base text-slate-500 dark:text-slate-400 max-w-xl mx-auto">
                  Paste your notes or describe a topic. Get flashcards to flip through and a quiz to test yourself — all generated by AI.
                </p>
              </div>
            )}

            {status === "idle" && !content && (
              <InputForm
                onSubmit={handleGenerate}
                isLoading={false}
                error={null}
                onClearError={() => {}}
              />
            )}

            {status === "loading" && (
              <div>
                <InputForm
                  onSubmit={handleGenerate}
                  isLoading={true}
                  error={null}
                  onClearError={() => {}}
                />
                <LoadingState />
              </div>
            )}

            {status === "error" && (
              <ErrorState
                message={error || "Unknown error"}
                onRetry={handleRetry}
                onReset={handleReset}
                lastTopic={lastTopic}
              />
            )}

            {status === "success" && content && (
              <StudyView
                content={content}
                topic={lastTopic || ""}
                onReset={handleReset}
                onNew={handleNew}
              />
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="mx-auto max-w-7xl px-4 sm:px-6 py-6 border-t border-slate-200 dark:border-slate-800 mt-8">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-sm text-slate-400 dark:text-slate-500">
          <p>StudyForge — AI-powered study assistant</p>
          <a
            href="https://github.com"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 hover:text-slate-600 dark:hover:text-slate-300 transition-colors"
          >
            <Github className="h-4 w-4" />
            Source
          </a>
        </div>
      </footer>
    </div>
  );
}

export default App;
