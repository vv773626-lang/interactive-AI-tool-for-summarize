import { createClient } from "@supabase/supabase-js";
import type { StudyContent } from "./types";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface SavedSession {
  id: string;
  topic: string;
  content: StudyContent;
  created_at: string;
}

export async function saveSession(topic: string, content: StudyContent): Promise<string | null> {
  const { data, error } = await supabase
    .from("study_sessions")
    .insert({ topic, content })
    .select("id")
    .single();

  if (error || !data) return null;
  return data.id;
}

export async function loadSessions(): Promise<SavedSession[]> {
  const { data, error } = await supabase
    .from("study_sessions")
    .select("id, topic, content, created_at")
    .order("created_at", { ascending: false })
    .limit(20);

  if (error || !data) return [];
  return data as SavedSession[];
}

export async function deleteSession(id: string): Promise<boolean> {
  const { error } = await supabase.from("study_sessions").delete().eq("id", id);
  return !error;
}
