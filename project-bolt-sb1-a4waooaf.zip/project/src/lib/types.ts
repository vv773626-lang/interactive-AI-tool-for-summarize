export interface Flashcard {
  id: string;
  front: string;
  back: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface StudyContent {
  title: string;
  flashcards: Flashcard[];
  quiz: QuizQuestion[];
}

export interface GenerateResponse {
  content: StudyContent;
  sessionId?: string;
}

export interface ApiError {
  error: string;
}
