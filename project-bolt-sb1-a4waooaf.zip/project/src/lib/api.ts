import type { GenerateResponse, StudyContent } from "./types";

const FUNCTION_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate`;

export class GenerateError extends Error {
  constructor(message: string, public retryable: boolean = true) {
    super(message);
    this.name = "GenerateError";
  }
}

function validateContent(data: unknown): StudyContent {
  if (typeof data !== "object" || data === null) {
    throw new GenerateError("The AI response wasn't a valid object.");
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== "string" || obj.title.trim().length === 0) {
    throw new GenerateError("The AI response is missing a title.");
  }

  if (!Array.isArray(obj.flashcards) || obj.flashcards.length === 0) {
    throw new GenerateError("The AI response has no flashcards.");
  }

  if (!Array.isArray(obj.quiz) || obj.quiz.length === 0) {
    throw new GenerateError("The AI response has no quiz questions.");
  }

  // Validate flashcards
  for (let i = 0; i < obj.flashcards.length; i++) {
    const fc = obj.flashcards[i] as Record<string, unknown>;
    if (!fc || typeof fc.front !== "string" || typeof fc.back !== "string") {
      throw new GenerateError(`Flashcard ${i + 1} is malformed.`);
    }
  }

  // Validate quiz
  for (let i = 0; i < obj.quiz.length; i++) {
    const q = obj.quiz[i] as Record<string, unknown>;
    if (!q || typeof q.question !== "string") {
      throw new GenerateError(`Quiz question ${i + 1} is malformed.`);
    }
    if (!Array.isArray(q.options) || q.options.length !== 4 || !q.options.every((o) => typeof o === "string")) {
      throw new GenerateError(`Quiz question ${i + 1} needs exactly 4 text options.`);
    }
    if (typeof q.correctIndex !== "number" || q.correctIndex < 0 || q.correctIndex > 3) {
      throw new GenerateError(`Quiz question ${i + 1} has an invalid correct answer.`);
    }
    if (typeof q.explanation !== "string") {
      q.explanation = "";
    }
  }

  // Normalize IDs
  const content: StudyContent = {
    title: obj.title,
    flashcards: obj.flashcards.map((fc: Record<string, unknown>, i: number) => ({
      id: (fc.id as string) || `fc-${i + 1}`,
      front: fc.front as string,
      back: fc.back as string,
    })),
    quiz: obj.quiz.map((q: Record<string, unknown>, i: number) => ({
      id: (q.id as string) || `q-${i + 1}`,
      question: q.question as string,
      options: q.options as string[],
      correctIndex: q.correctIndex as number,
      explanation: (q.explanation as string) || "",
    })),
  };

  return content;
}

interface RequestOptions {
  signal?: AbortSignal;
}

export async function generateStudySet(topic: string, opts: RequestOptions = {}): Promise<GenerateResponse> {
  let response: Response;
  try {
    response = await fetch(FUNCTION_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      },
      body: JSON.stringify({ topic }),
      signal: opts.signal,
    });
  } catch (err) {
    if (err instanceof DOMException && err.name === "AbortError") {
      throw new GenerateError("Request was cancelled.", false);
    }
    throw new GenerateError("Couldn't reach the server. Check your connection and try again.");
  }

  if (!response.ok) {
    let message = `Server error (${response.status})`;
    try {
      const body = await response.json();
      if (body?.error) message = body.error;
    } catch {
      // response body wasn't JSON — use the status message
    }

    // 502 = the AI returned bad output (already retried server-side)
    const retryable = response.status !== 502 || true;
    throw new GenerateError(message, retryable);
  }

  let body: unknown;
  try {
    body = await response.json();
  } catch {
    throw new GenerateError("The server returned invalid JSON.");
  }

  const obj = body as Record<string, unknown>;
  if (!obj || typeof obj !== "object") {
    throw new GenerateError("The server response was malformed.");
  }

  if (obj.error) {
    throw new GenerateError(obj.error as string);
  }

  if (!obj.content) {
    throw new GenerateError("The server response is missing the study content.");
  }

  // Double-check the shape on the client too — don't trust the server blindly
  const content = validateContent(obj.content);

  return {
    content,
    sessionId: obj.sessionId as string | undefined,
  };
}
