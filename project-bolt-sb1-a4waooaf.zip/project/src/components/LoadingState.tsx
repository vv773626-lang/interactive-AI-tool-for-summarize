import { Loader2, Sparkles } from "lucide-react";

export function LoadingState() {
  return (
    <div className="w-full max-w-2xl mx-auto flex flex-col items-center justify-center py-16">
      <div className="relative">
        <div className="absolute inset-0 animate-ping rounded-full bg-teal-400/30" />
        <div className="relative flex h-16 w-16 items-center justify-center rounded-full bg-teal-100 dark:bg-teal-950/50 ring-1 ring-teal-300 dark:ring-teal-800">
          <Sparkles className="h-8 w-8 text-teal-600 dark:text-teal-400" />
        </div>
      </div>
      <h3 className="mt-6 text-lg font-semibold text-slate-800 dark:text-slate-200">
        Creating your study set…
      </h3>
      <p className="mt-1 text-sm text-slate-500 dark:text-slate-400 text-center max-w-sm">
        The AI is reading your notes and generating flashcards plus a quiz. This usually takes a few seconds.
      </p>
      <div className="mt-6 flex items-center gap-2 text-sm text-slate-400 dark:text-slate-500">
        <Loader2 className="h-4 w-4 animate-spin" />
        <span>Generating structured content…</span>
      </div>
    </div>
  );
}
