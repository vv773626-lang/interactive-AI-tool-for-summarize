import { useState, useCallback } from "react";
import { ChevronLeft, ChevronRight, RotateCcw, Check, Eye, EyeOff } from "lucide-react";
import type { Flashcard } from "@/lib/types";

interface FlashcardViewerProps {
  cards: Flashcard[];
}

export function FlashcardViewer({ cards }: FlashcardViewerProps) {
  const [index, setIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [knownCards, setKnownCards] = useState<Set<string>>(new Set());

  const card = cards[index];
  const isKnown = knownCards.has(card.id);

  const goNext = useCallback(() => {
    setFlipped(false);
    setIndex((prev) => (prev + 1) % cards.length);
  }, [cards.length]);

  const goPrev = useCallback(() => {
    setFlipped(false);
    setIndex((prev) => (prev - 1 + cards.length) % cards.length);
  }, [cards.length]);

  const toggleKnown = useCallback(() => {
    setKnownCards((prev) => {
      const next = new Set(prev);
      if (next.has(card.id)) {
        next.delete(card.id);
      } else {
        next.add(card.id);
      }
      return next;
    });
  }, [card.id]);

  const reset = useCallback(() => {
    setKnownCards(new Set());
    setFlipped(false);
    setIndex(0);
  }, []);

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === "ArrowRight") {
        e.preventDefault();
        goNext();
      } else if (e.key === "ArrowLeft") {
        e.preventDefault();
        goPrev();
      } else if (e.key === " " || e.key === "Enter") {
        e.preventDefault();
        setFlipped((f) => !f);
      }
    },
    [goNext, goPrev],
  );

  return (
    <div className="w-full max-w-2xl mx-auto" onKeyDown={handleKeyDown} tabIndex={0} role="region" aria-label="Flashcards">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <h3 className="text-sm font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
            Flashcards
          </h3>
          <span className="text-xs font-medium text-slate-400 dark:text-slate-500">
            {knownCards.size}/{cards.length} known
          </span>
        </div>
        {knownCards.size > 0 && (
          <button
            onClick={reset}
            className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-500 dark:text-slate-400 hover:text-teal-600 dark:hover:text-teal-400 transition-colors"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            Reset marks
          </button>
        )}
      </div>

      {/* Card */}
      <div
        onClick={() => setFlipped((f) => !f)}
        className="relative cursor-pointer select-none"
        style={{ perspective: "1000px" }}
        role="button"
        aria-label={`Card ${index + 1} of ${cards.length}: ${flipped ? "showing answer" : "showing question"}. Click or press space to flip.`}
      >
        <div
          className="relative w-full transition-transform duration-500"
          style={{
            transformStyle: "preserve-3d",
            transform: flipped ? "rotateY(180deg)" : "rotateY(0deg)",
            minHeight: "280px",
          }}
        >
          {/* Front */}
          <div
            className="absolute inset-0 flex flex-col items-center justify-center rounded-2xl bg-white dark:bg-slate-800 shadow-xl ring-1 ring-slate-200 dark:ring-slate-700 p-8"
            style={{ backfaceVisibility: "hidden", WebkitBackfaceVisibility: "hidden" }}
          >
            <span className="absolute top-4 left-4 text-xs font-semibold uppercase tracking-wider text-teal-600 dark:text-teal-400">
              Question
            </span>
            <span className="absolute top-4 right-4 text-xs font-medium text-slate-400 dark:text-slate-500">
              {index + 1} / {cards.length}
            </span>
            <p className="text-xl font-semibold text-center text-slate-900 dark:text-slate-100 leading-relaxed max-w-lg">
              {card.front}
            </p>
            <div className="absolute bottom-4 flex items-center gap-1.5 text-xs text-slate-400 dark:text-slate-500">
              <Eye className="h-3.5 w-3.5" />
              <span>Click to flip</span>
            </div>
          </div>

          {/* Back */}
          <div
            className="absolute inset-0 flex flex-col items-center justify-center rounded-2xl bg-teal-600 dark:bg-teal-700 shadow-xl ring-1 ring-teal-700 dark:ring-teal-600 p-8"
            style={{
              backfaceVisibility: "hidden",
              WebkitBackfaceVisibility: "hidden",
              transform: "rotateY(180deg)",
            }}
          >
            <span className="absolute top-4 left-4 text-xs font-semibold uppercase tracking-wider text-teal-100">
              Answer
            </span>
            <span className="absolute top-4 right-4 text-xs font-medium text-teal-100/70">
              {index + 1} / {cards.length}
            </span>
            <p className="text-lg text-center text-white leading-relaxed max-w-lg">
              {card.back}
            </p>
            <div className="absolute bottom-4 flex items-center gap-1.5 text-xs text-teal-100/70">
              <EyeOff className="h-3.5 w-3.5" />
              <span>Click to flip back</span>
            </div>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="mt-5 flex items-center justify-between">
        <button
          onClick={goPrev}
          disabled={cards.length <= 1}
          className="inline-flex items-center gap-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 px-4 py-2 text-sm font-medium text-slate-600 dark:text-slate-300 ring-1 ring-slate-200 dark:ring-slate-700 transition-all hover:bg-slate-200 dark:hover:bg-slate-700 active:scale-95 disabled:opacity-40"
          aria-label="Previous card"
        >
          <ChevronLeft className="h-4 w-4" />
          <span className="hidden sm:inline">Prev</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={toggleKnown}
            className={`inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-medium transition-all active:scale-95 ${
              isKnown
                ? "bg-green-100 dark:bg-green-950/50 text-green-700 dark:text-green-400 ring-1 ring-green-300 dark:ring-green-800"
                : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 ring-1 ring-slate-200 dark:ring-slate-700 hover:bg-green-50 dark:hover:bg-green-950/30"
            }`}
          >
            <Check className="h-4 w-4" />
            {isKnown ? "Known" : "Mark as known"}
          </button>
        </div>

        <button
          onClick={goNext}
          disabled={cards.length <= 1}
          className="inline-flex items-center gap-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 px-4 py-2 text-sm font-medium text-slate-600 dark:text-slate-300 ring-1 ring-slate-200 dark:ring-slate-700 transition-all hover:bg-slate-200 dark:hover:bg-slate-700 active:scale-95 disabled:opacity-40"
          aria-label="Next card"
        >
          <span className="hidden sm:inline">Next</span>
          <ChevronRight className="h-4 w-4" />
        </button>
      </div>

      {/* Progress dots */}
      <div className="mt-4 flex items-center justify-center gap-1.5">
        {cards.map((c, i) => (
          <button
            key={c.id}
            onClick={() => {
              setFlipped(false);
              setIndex(i);
            }}
            className={`h-2 rounded-full transition-all ${
              i === index
                ? "w-6 bg-teal-600 dark:bg-teal-400"
                : knownCards.has(c.id)
                  ? "w-2 bg-green-400 dark:bg-green-600"
                  : "w-2 bg-slate-300 dark:bg-slate-600 hover:bg-slate-400"
            }`}
            aria-label={`Go to card ${i + 1}`}
          />
        ))}
      </div>

      <p className="mt-3 text-center text-xs text-slate-400 dark:text-slate-500">
        Use arrow keys to navigate, space to flip
      </p>
    </div>
  );
}
