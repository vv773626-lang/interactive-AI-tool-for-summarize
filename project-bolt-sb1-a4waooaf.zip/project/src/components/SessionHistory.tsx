import { History, Trash2, Clock, ChevronRight } from "lucide-react";
import type { SavedSession } from "@/lib/supabase";
import type { StudyContent } from "@/lib/types";

interface SessionHistoryProps {
  sessions: SavedSession[];
  loading: boolean;
  onSelect: (session: SavedSession) => void;
  onDelete: (id: string) => void;
  activeSessionId: string | null;
}

export function SessionHistory({
  sessions,
  loading,
  onSelect,
  onDelete,
  activeSessionId,
}: SessionHistoryProps) {
  return (
    <div className="w-full">
      <div className="flex items-center gap-2 mb-4">
        <History className="h-4 w-4 text-slate-400 dark:text-slate-500" />
        <h3 className="text-sm font-semibold text-slate-600 dark:text-slate-400">
          Recent study sets
        </h3>
      </div>

      {loading ? (
        <div className="space-y-2">
          {[1, 2, 3].map((i) => (
            <div
              key={i}
              className="h-16 rounded-xl bg-slate-100 dark:bg-slate-800 animate-pulse"
            />
          ))}
        </div>
      ) : sessions.length === 0 ? (
        <div className="rounded-xl border border-dashed border-slate-200 dark:border-slate-700 p-6 text-center">
          <p className="text-sm text-slate-400 dark:text-slate-500">
            No saved study sets yet. Generate one to get started.
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {sessions.map((session) => {
            const content = session.content as StudyContent;
            const isActive = session.id === activeSessionId;
            return (
              <div
                key={session.id}
                className={`group flex items-center gap-3 rounded-xl p-3 ring-1 transition-all cursor-pointer ${
                  isActive
                    ? "bg-teal-50 dark:bg-teal-950/30 ring-teal-300 dark:ring-teal-700"
                    : "bg-white dark:bg-slate-800 ring-slate-200 dark:ring-slate-700 hover:ring-teal-300 dark:hover:ring-teal-700 hover:bg-teal-50/50 dark:hover:bg-teal-950/20"
                }`}
                onClick={() => onSelect(session)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    onSelect(session);
                  }
                }}
              >
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-800 dark:text-slate-200 truncate">
                    {content?.title || session.topic.slice(0, 40)}
                  </p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <Clock className="h-3 w-3 text-slate-400 dark:text-slate-500 flex-shrink-0" />
                    <p className="text-xs text-slate-400 dark:text-slate-500 truncate">
                      {formatDate(session.created_at)}
                    </p>
                  </div>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDelete(session.id);
                  }}
                  className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40 opacity-0 group-hover:opacity-100 transition-all"
                  aria-label="Delete study set"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
                <ChevronRight className="h-4 w-4 text-slate-300 dark:text-slate-600 flex-shrink-0" />
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function formatDate(iso: string): string {
  const date = new Date(iso);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  const diffHr = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHr / 24);

  if (diffMin < 1) return "Just now";
  if (diffMin < 60) return `${diffMin}m ago`;
  if (diffHr < 24) return `${diffHr}h ago`;
  if (diffDay < 7) return `${diffDay}d ago`;
  return date.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}
