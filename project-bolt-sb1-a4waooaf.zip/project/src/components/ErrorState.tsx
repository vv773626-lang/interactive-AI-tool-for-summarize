import { AlertTriangle, RefreshCw, ArrowLeft } from "lucide-react";

interface ErrorStateProps {
  message: string;
  onRetry: () => void;
  onReset: () => void;
  lastTopic: string | null;
}

export function ErrorState({ message, onRetry, onReset, lastTopic }: ErrorStateProps) {
  return (
    <div className="w-full max-w-2xl mx-auto flex flex-col items-center justify-center py-16">
      <div className="flex h-16 w-16 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-950/50 ring-1 ring-amber-300 dark:ring-amber-800">
        <AlertTriangle className="h-8 w-8 text-amber-600 dark:text-amber-400" />
      </div>
      <h3 className="mt-6 text-lg font-semibold text-slate-800 dark:text-slate-200">
        The AI didn't return usable content
      </h3>
      <p className="mt-2 text-sm text-slate-500 dark:text-slate-400 text-center max-w-md">
        {message}
      </p>
      <p className="mt-1 text-xs text-slate-400 dark:text-slate-500 text-center max-w-md">
        The server already retried 3 times automatically. You can try again — sometimes a fresh request produces better output.
      </p>

      <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
        <button
          onClick={onRetry}
          className="inline-flex items-center gap-2 rounded-xl bg-teal-600 px-5 py-2.5 text-sm font-medium text-white shadow-sm transition-all hover:bg-teal-700 active:scale-95"
        >
          <RefreshCw className="h-4 w-4" />
          {lastTopic ? "Try again" : "Retry"}
        </button>
        <button
          onClick={onReset}
          className="inline-flex items-center gap-2 rounded-xl bg-slate-100 dark:bg-slate-800 px-5 py-2.5 text-sm font-medium text-slate-600 dark:text-slate-300 ring-1 ring-slate-200 dark:ring-slate-700 transition-all hover:bg-slate-200 dark:hover:bg-slate-700 active:scale-95"
        >
          <ArrowLeft className="h-4 w-4" />
          Start over
        </button>
      </div>
    </div>
  );
}
