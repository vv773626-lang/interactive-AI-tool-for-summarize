import { useState, useCallback } from "react";
import { Check, X, RotateCcw, ChevronRight, Trophy, AlertCircle } from "lucide-react";
import type { QuizQuestion } from "@/lib/types";

interface QuizViewerProps {
  questions: QuizQuestion[];
  onRestart: () => void;
}

type QuizPhase = "playing" | "results" | "retest" | "retest-results";

export function QuizViewer({ questions, onRestart }: QuizViewerProps) {
  const [phase, setPhase] = useState<QuizPhase>("playing");
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<(number | null)[]>(() =>
    questions.map(() => null),
  );
  const [selected, setSelected] = useState<number | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);

  const question = questions[currentIndex];
  const isLastQuestion = currentIndex === questions.length - 1;

  const handleSelect = useCallback(
    (optionIndex: number) => {
      if (showFeedback) return;
      setSelected(optionIndex);
    },
    [showFeedback],
  );

  const handleConfirm = useCallback(() => {
    if (selected === null) return;
    const newAnswers = [...answers];
    newAnswers[currentIndex] = selected;
    setAnswers(newAnswers);
    setShowFeedback(true);
  }, [selected, answers, currentIndex]);

  const handleNext = useCallback(() => {
    if (isLastQuestion) {
      setPhase("results");
    } else {
      setCurrentIndex((i) => i + 1);
      setSelected(null);
      setShowFeedback(false);
    }
  }, [isLastQuestion]);

  const handleRetry = useCallback(() => {
    // Re-test only the wrong answers
    const wrongIndices = answers
      .map((ans, i) => (ans !== null && ans !== questions[i].correctIndex ? i : -1))
      .filter((i) => i !== -1);

    if (wrongIndices.length === 0) {
      // Everything correct — just restart
      setAnswers(questions.map(() => null));
      setCurrentIndex(0);
      setSelected(null);
      setShowFeedback(false);
      setPhase("playing");
      return;
    }

    // Keep only wrong questions, reset their answers
    const wrongQuestions = wrongIndices.map((i) => questions[i]);
    // We'll use a separate state path for re-test
    setRetestQuestions(wrongQuestions);
    setRetestAnswers(wrongQuestions.map(() => null));
    setRetestIndex(0);
    setRetestSelected(null);
    setRetestShowFeedback(false);
    setPhase("retest");
  }, [answers, questions]);

  // Retest state
  const [retestQuestions, setRetestQuestions] = useState<QuizQuestion[]>([]);
  const [retestAnswers, setRetestAnswers] = useState<(number | null)[]>([]);
  const [retestIndex, setRetestIndex] = useState(0);
  const [retestSelected, setRetestSelected] = useState<number | null>(null);
  const [retestShowFeedback, setRetestShowFeedback] = useState(false);

  const retestQuestion = retestQuestions[retestIndex];
  const isLastRetest = retestIndex === retestQuestions.length - 1;

  const handleRetestSelect = useCallback(
    (optionIndex: number) => {
      if (retestShowFeedback) return;
      setRetestSelected(optionIndex);
    },
    [retestShowFeedback],
  );

  const handleRetestConfirm = useCallback(() => {
    if (retestSelected === null) return;
    const newAnswers = [...retestAnswers];
    newAnswers[retestIndex] = retestSelected;
    setRetestAnswers(newAnswers);
    setRetestShowFeedback(true);
  }, [retestSelected, retestAnswers, retestIndex]);

  const handleRetestNext = useCallback(() => {
    if (isLastRetest) {
      setPhase("retest-results");
    } else {
      setRetestIndex((i) => i + 1);
      setRetestSelected(null);
      setRetestShowFeedback(false);
    }
  }, [isLastRetest]);

  const handleFullRestart = useCallback(() => {
    setAnswers(questions.map(() => null));
    setCurrentIndex(0);
    setSelected(null);
    setShowFeedback(false);
    setPhase("playing");
  }, [questions]);

  // Results calculation
  const correctCount = answers.filter((ans, i) => ans === questions[i].correctIndex).length;
  const scorePercent = Math.round((correctCount / questions.length) * 100);

  const retestCorrectCount = retestAnswers.filter(
    (ans, i) => ans === retestQuestions[i]?.correctIndex,
  ).length;
  const retestScorePercent = retestQuestions.length > 0
    ? Math.round((retestCorrectCount / retestQuestions.length) * 100)
    : 0;

  // Results phase
  if (phase === "results") {
    const wrongCount = questions.length - correctCount;
    return (
      <div className="w-full max-w-2xl mx-auto">
        <div className="flex flex-col items-center text-center py-6">
          <div className={`flex h-20 w-20 items-center justify-center rounded-full ${
            scorePercent >= 80
              ? "bg-green-100 dark:bg-green-950/50 ring-1 ring-green-300 dark:ring-green-800"
              : scorePercent >= 50
                ? "bg-amber-100 dark:bg-amber-950/50 ring-1 ring-amber-300 dark:ring-amber-800"
                : "bg-red-100 dark:bg-red-950/50 ring-1 ring-red-300 dark:ring-red-800"
          }`}>
            <Trophy className={`h-10 w-10 ${
              scorePercent >= 80
                ? "text-green-600 dark:text-green-400"
                : scorePercent >= 50
                  ? "text-amber-600 dark:text-amber-400"
                  : "text-red-600 dark:text-red-400"
            }`} />
          </div>
          <h3 className="mt-4 text-2xl font-bold text-slate-900 dark:text-slate-100">
            {scorePercent}%
          </h3>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            You got {correctCount} out of {questions.length} correct
          </p>
        </div>

        {/* Question review */}
        <div className="mt-6 space-y-3">
          {questions.map((q, i) => {
            const userAnswer = answers[i];
            const isCorrect = userAnswer === q.correctIndex;
            return (
              <div
                key={q.id}
                className="rounded-xl bg-white dark:bg-slate-800 p-4 ring-1 ring-slate-200 dark:ring-slate-700"
              >
                <div className="flex items-start gap-3">
                  <div className={`flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full ${
                    isCorrect
                      ? "bg-green-100 dark:bg-green-950/50"
                      : "bg-red-100 dark:bg-red-950/50"
                  }`}>
                    {isCorrect ? (
                      <Check className="h-4 w-4 text-green-600 dark:text-green-400" />
                    ) : (
                      <X className="h-4 w-4 text-red-600 dark:text-red-400" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-800 dark:text-slate-200">
                      {q.question}
                    </p>
                    {!isCorrect && (
                      <div className="mt-2 space-y-1 text-xs">
                        {userAnswer !== null && (
                          <p className="text-red-600 dark:text-red-400">
                            Your answer: {q.options[userAnswer]}
                          </p>
                        )}
                        <p className="text-green-600 dark:text-green-400">
                          Correct: {q.options[q.correctIndex]}
                        </p>
                      </div>
                    )}
                    {q.explanation && (
                      <p className="mt-2 text-xs text-slate-500 dark:text-slate-400 italic">
                        {q.explanation}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
          {wrongCount > 0 && (
            <button
              onClick={handleRetry}
              className="inline-flex items-center gap-2 rounded-xl bg-teal-600 px-5 py-2.5 text-sm font-medium text-white shadow-sm transition-all hover:bg-teal-700 active:scale-95"
            >
              <RotateCcw className="h-4 w-4" />
              Re-test {wrongCount} wrong {wrongCount === 1 ? "answer" : "answers"}
            </button>
          )}
          <button
            onClick={onRestart}
            className="inline-flex items-center gap-2 rounded-xl bg-slate-100 dark:bg-slate-800 px-5 py-2.5 text-sm font-medium text-slate-600 dark:text-slate-300 ring-1 ring-slate-200 dark:ring-slate-700 transition-all hover:bg-slate-200 dark:hover:bg-slate-700 active:scale-95"
          >
            <RotateCcw className="h-4 w-4" />
            Restart full quiz
          </button>
        </div>
      </div>
    );
  }

  // Retest results
  if (phase === "retest-results") {
    return (
      <div className="w-full max-w-2xl mx-auto">
        <div className="flex flex-col items-center text-center py-6">
          <div className="flex h-20 w-20 items-center justify-center rounded-full bg-teal-100 dark:bg-teal-950/50 ring-1 ring-teal-300 dark:ring-teal-800">
            <Trophy className="h-10 w-10 text-teal-600 dark:text-teal-400" />
          </div>
          <h3 className="mt-4 text-2xl font-bold text-slate-900 dark:text-slate-100">
            Re-test: {retestScorePercent}%
          </h3>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            You got {retestCorrectCount} out of {retestQuestions.length} correct this time
          </p>
        </div>

        <div className="mt-6 space-y-3">
          {retestQuestions.map((q, i) => {
            const userAnswer = retestAnswers[i];
            const isCorrect = userAnswer === q.correctIndex;
            return (
              <div
                key={q.id}
                className="rounded-xl bg-white dark:bg-slate-800 p-4 ring-1 ring-slate-200 dark:ring-slate-700"
              >
                <div className="flex items-start gap-3">
                  <div className={`flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full ${
                    isCorrect ? "bg-green-100 dark:bg-green-950/50" : "bg-red-100 dark:bg-red-950/50"
                  }`}>
                    {isCorrect ? (
                      <Check className="h-4 w-4 text-green-600 dark:text-green-400" />
                    ) : (
                      <X className="h-4 w-4 text-red-600 dark:text-red-400" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-800 dark:text-slate-200">{q.question}</p>
                    {!isCorrect && (
                      <div className="mt-2 space-y-1 text-xs">
                        {userAnswer !== null && (
                          <p className="text-red-600 dark:text-red-400">
                            Your answer: {q.options[userAnswer]}
                          </p>
                        )}
                        <p className="text-green-600 dark:text-green-400">
                          Correct: {q.options[q.correctIndex]}
                        </p>
                      </div>
                    )}
                    {q.explanation && (
                      <p className="mt-2 text-xs text-slate-500 dark:text-slate-400 italic">{q.explanation}</p>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-6 flex justify-center">
          <button
            onClick={onRestart}
            className="inline-flex items-center gap-2 rounded-xl bg-slate-100 dark:bg-slate-800 px-5 py-2.5 text-sm font-medium text-slate-600 dark:text-slate-300 ring-1 ring-slate-200 dark:ring-slate-700 transition-all hover:bg-slate-200 dark:hover:bg-slate-700 active:scale-95"
          >
            <RotateCcw className="h-4 w-4" />
            Back to study set
          </button>
        </div>
      </div>
    );
  }

  // Retest playing
  if (phase === "retest") {
    return (
      <QuizPlaying
        questions={retestQuestions}
        currentIndex={retestIndex}
        selected={retestSelected}
        showFeedback={retestShowFeedback}
        answers={retestAnswers}
        onSelect={handleRetestSelect}
        onConfirm={handleRetestConfirm}
        onNext={handleRetestNext}
        isLast={isLastRetest}
        label="Re-test"
      />
    );
  }

  // Playing
  return (
    <QuizPlaying
      questions={questions}
      currentIndex={currentIndex}
      selected={selected}
      showFeedback={showFeedback}
      answers={answers}
      onSelect={handleSelect}
      onConfirm={handleConfirm}
      onNext={handleNext}
      isLast={isLastQuestion}
      label="Quiz"
    />
  );
}

interface QuizPlayingProps {
  questions: QuizQuestion[];
  currentIndex: number;
  selected: number | null;
  showFeedback: boolean;
  answers: (number | null)[];
  onSelect: (index: number) => void;
  onConfirm: () => void;
  onNext: () => void;
  isLast: boolean;
  label: string;
}

function QuizPlaying({
  questions,
  currentIndex,
  selected,
  showFeedback,
  answers,
  onSelect,
  onConfirm,
  onNext,
  isLast,
  label,
}: QuizPlayingProps) {
  const question = questions[currentIndex];
  const isCorrect = showFeedback && selected === question.correctIndex;
  const answeredCount = answers.filter((a) => a !== null).length;

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
          {label}
        </h3>
        <span className="text-xs font-medium text-slate-400 dark:text-slate-500">
          {currentIndex + 1} of {questions.length}
        </span>
      </div>

      {/* Progress bar */}
      <div className="mb-6 h-1.5 w-full rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
        <div
          className="h-full bg-teal-500 dark:bg-teal-400 transition-all duration-300 ease-out"
          style={{ width: `${((currentIndex + (showFeedback ? 1 : 0)) / questions.length) * 100}%` }}
        />
      </div>

      {/* Question */}
      <div className="rounded-2xl bg-white dark:bg-slate-800 p-6 shadow-sm ring-1 ring-slate-200 dark:ring-slate-700">
        <p className="text-lg font-semibold text-slate-900 dark:text-slate-100 leading-relaxed">
          {question.question}
        </p>

        {/* Options */}
        <div className="mt-5 space-y-2.5">
          {question.options.map((option, i) => {
            const isSelected = selected === i;
            const isCorrectOption = i === question.correctIndex;

            let stateClass = "bg-slate-50 dark:bg-slate-900/50 ring-slate-200 dark:ring-slate-700 hover:ring-teal-300 dark:hover:ring-teal-700 hover:bg-teal-50 dark:hover:bg-teal-950/20";
            if (showFeedback) {
              if (isCorrectOption) {
                stateClass = "bg-green-50 dark:bg-green-950/30 ring-green-300 dark:ring-green-700";
              } else if (isSelected) {
                stateClass = "bg-red-50 dark:bg-red-950/30 ring-red-300 dark:ring-red-700";
              } else {
                stateClass = "bg-slate-50 dark:bg-slate-900/50 ring-slate-200 dark:ring-slate-700 opacity-60";
              }
            } else if (isSelected) {
              stateClass = "bg-teal-50 dark:bg-teal-950/30 ring-2 ring-teal-500 dark:ring-teal-400";
            }

            return (
              <button
                key={i}
                onClick={() => onSelect(i)}
                disabled={showFeedback}
                className={`flex w-full items-center gap-3 rounded-xl px-4 py-3.5 text-left text-sm font-medium text-slate-700 dark:text-slate-200 ring-1 transition-all ${stateClass} ${!showFeedback ? "active:scale-[0.99] cursor-pointer" : "cursor-default"}`}
              >
                <span className={`flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-full text-xs font-bold ${
                  showFeedback && isCorrectOption
                    ? "bg-green-500 text-white"
                    : showFeedback && isSelected
                      ? "bg-red-500 text-white"
                      : isSelected
                        ? "bg-teal-500 text-white"
                        : "bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300"
                }`}>
                  {String.fromCharCode(65 + i)}
                </span>
                <span className="flex-1">{option}</span>
                {showFeedback && isCorrectOption && <Check className="h-5 w-5 text-green-600 dark:text-green-400" />}
                {showFeedback && isSelected && !isCorrectOption && <X className="h-5 w-5 text-red-600 dark:text-red-400" />}
              </button>
            );
          })}
        </div>

        {/* Feedback */}
        {showFeedback && (
          <div className={`mt-4 rounded-xl p-4 ${
            isCorrect
              ? "bg-green-50 dark:bg-green-950/30 ring-1 ring-green-200 dark:ring-green-800"
              : "bg-amber-50 dark:bg-amber-950/30 ring-1 ring-amber-200 dark:ring-amber-800"
          }`}>
            <div className="flex items-start gap-2.5">
              {isCorrect ? (
                <Check className="h-5 w-5 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="h-5 w-5 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
              )}
              <div>
                <p className={`text-sm font-semibold ${isCorrect ? "text-green-800 dark:text-green-300" : "text-amber-800 dark:text-amber-300"}`}>
                  {isCorrect ? "Correct!" : "Not quite right"}
                </p>
                {question.explanation && (
                  <p className="mt-0.5 text-sm text-slate-600 dark:text-slate-300">
                    {question.explanation}
                  </p>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Action button */}
      <div className="mt-5 flex justify-end">
        {!showFeedback ? (
          <button
            onClick={onConfirm}
            disabled={selected === null}
            className="inline-flex items-center gap-2 rounded-xl bg-teal-600 px-6 py-2.5 text-sm font-medium text-white shadow-sm transition-all hover:bg-teal-700 active:scale-95 disabled:cursor-not-allowed disabled:opacity-40"
          >
            Confirm answer
          </button>
        ) : (
          <button
            onClick={onNext}
            className="inline-flex items-center gap-2 rounded-xl bg-teal-600 px-6 py-2.5 text-sm font-medium text-white shadow-sm transition-all hover:bg-teal-700 active:scale-95"
          >
            {isLast ? "See results" : "Next question"}
            <ChevronRight className="h-4 w-4" />
          </button>
        )}
      </div>

      <p className="mt-3 text-center text-xs text-slate-400 dark:text-slate-500">
        {answeredCount} of {questions.length} answered
      </p>
    </div>
  );
}
