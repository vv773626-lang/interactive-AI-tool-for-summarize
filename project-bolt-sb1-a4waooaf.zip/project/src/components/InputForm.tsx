import { useState, useRef, useEffect } from "react";
import { Loader2, Send, AlertCircle } from "lucide-react";

interface InputFormProps {
  onSubmit: (topic: string) => void;
  isLoading: boolean;
  error: string | null;
  onClearError: () => void;
}

const EXAMPLES = [
  "The water cycle: evaporation, condensation, precipitation",
  "Key events of the French Revolution",
  "Photosynthesis and cellular respiration",
  "Introduction to recursion in programming",
];

export function InputForm({ onSubmit, isLoading, error, onClearError }: InputFormProps) {
  const [value, setValue] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-resize textarea
  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 240) + "px";
  }, [value]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = value.trim();
    if (trimmed.length === 0 || isLoading) return;
    onSubmit(trimmed);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const handleExample = (example: string) => {
    setValue(example);
    onClearError();
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      <form onSubmit={handleSubmit} className="relative">
        <div className="relative rounded-2xl bg-white dark:bg-slate-800 shadow-lg shadow-slate-200/50 dark:shadow-black/20 ring-1 ring-slate-200 dark:ring-slate-700 transition-all focus-within:ring-2 focus-within:ring-teal-500 dark:focus-within:ring-teal-400">
          <textarea
            ref={textareaRef}
            value={value}
            onChange={(e) => {
              setValue(e.target.value);
              if (error) onClearError();
            }}
            onKeyDown={handleKeyDown}
            disabled={isLoading}
            placeholder="Paste your notes or describe a topic you want to study…"
            rows={3}
            className="w-full resize-none bg-transparent px-5 pt-4 pb-14 text-base text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none disabled:opacity-60"
            aria-label="Study topic input"
          />
          <div className="absolute bottom-3 right-3 flex items-center gap-2">
            {value.trim().length > 0 && !isLoading && (
              <span className="text-xs text-slate-400 dark:text-slate-500 mr-1 hidden sm:inline">
                {value.length} chars
              </span>
            )}
            <button
              type="submit"
              disabled={value.trim().length === 0 || isLoading}
              className="inline-flex items-center gap-2 rounded-xl bg-teal-600 px-4 py-2 text-sm font-medium text-white shadow-sm transition-all hover:bg-teal-700 active:scale-95 disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:bg-teal-600"
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Generating…</span>
                </>
              ) : (
                <>
                  <Send className="h-4 w-4" />
                  <span>Generate</span>
                </>
              )}
            </button>
          </div>
        </div>
      </form>

      {error && (
        <div className="mt-3 flex items-start gap-3 rounded-xl bg-red-50 dark:bg-red-950/40 px-4 py-3 ring-1 ring-red-200 dark:ring-red-900">
          <AlertCircle className="h-5 w-5 flex-shrink-0 text-red-600 dark:text-red-400 mt-0.5" />
          <div className="flex-1">
            <p className="text-sm font-medium text-red-800 dark:text-red-200">Something went wrong</p>
            <p className="text-sm text-red-700 dark:text-red-300 mt-0.5">{error}</p>
          </div>
          <button
            onClick={onClearError}
            className="text-sm font-medium text-red-600 dark:text-red-400 hover:underline"
          >
            Dismiss
          </button>
        </div>
      )}

      {!isLoading && !error && (
        <div className="mt-5">
          <p className="text-xs font-medium uppercase tracking-wide text-slate-400 dark:text-slate-500 mb-2">
            Try an example
          </p>
          <div className="flex flex-wrap gap-2">
            {EXAMPLES.map((ex) => (
              <button
                key={ex}
                onClick={() => handleExample(ex)}
                className="rounded-full bg-slate-100 dark:bg-slate-800 px-3 py-1.5 text-xs font-medium text-slate-600 dark:text-slate-300 ring-1 ring-slate-200 dark:ring-slate-700 transition-all hover:bg-teal-50 hover:text-teal-700 hover:ring-teal-300 dark:hover:bg-teal-950/40 dark:hover:text-teal-300 dark:hover:ring-teal-800"
              >
                {ex}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
