import { useState, useCallback } from "react";
import { Layers, HelpCircle, RotateCcw, Plus, ArrowLeft } from "lucide-react";
import type { StudyContent } from "@/lib/types";
import { FlashcardViewer } from "./FlashcardViewer";
import { QuizViewer } from "./QuizViewer";

interface StudyViewProps {
  content: StudyContent;
  topic: string;
  onReset: () => void;
  onNew: () => void;
}

type Tab = "flashcards" | "quiz";

export function StudyView({ content, topic, onReset, onNew }: StudyViewProps) {
  const [tab, setTab] = useState<Tab>("flashcards");
  // Key to force-remount quiz for restart
  const [quizKey, setQuizKey] = useState(0);

  const handleQuizRestart = useCallback(() => {
    setQuizKey((k) => k + 1);
  }, []);

  return (
    <div className="w-full max-w-5xl mx-auto">
      {/* Header */}
      <div className="mb-6">
        <button
          onClick={onReset}
          className="inline-flex items-center gap-1.5 text-sm font-medium text-slate-500 dark:text-slate-400 hover:text-teal-600 dark:hover:text-teal-400 transition-colors mb-3"
        >
          <ArrowLeft className="h-4 w-4" />
          New study set
        </button>
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
          <div className="flex-1 min-w-0">
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-slate-100 leading-snug">
              {content.title}
            </h2>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400 line-clamp-2">
              From: {topic}
            </p>
          </div>
          <button
            onClick={onNew}
            className="inline-flex items-center gap-2 rounded-xl bg-slate-100 dark:bg-slate-800 px-4 py-2 text-sm font-medium text-slate-600 dark:text-slate-300 ring-1 ring-slate-200 dark:ring-slate-700 transition-all hover:bg-slate-200 dark:hover:bg-slate-700 active:scale-95 flex-shrink-0"
          >
            <Plus className="h-4 w-4" />
            New topic
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="mb-6 flex items-center gap-1 rounded-xl bg-slate-100 dark:bg-slate-800 p-1 w-fit">
        <button
          onClick={() => setTab("flashcards")}
          className={`inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition-all ${
            tab === "flashcards"
              ? "bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-sm"
              : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300"
          }`}
        >
          <Layers className="h-4 w-4" />
          Flashcards
          <span className="ml-1 rounded-full bg-slate-200 dark:bg-slate-600 px-2 py-0.5 text-xs font-semibold text-slate-600 dark:text-slate-300">
            {content.flashcards.length}
          </span>
        </button>
        <button
          onClick={() => setTab("quiz")}
          className={`inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition-all ${
            tab === "quiz"
              ? "bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-sm"
              : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300"
          }`}
        >
          <HelpCircle className="h-4 w-4" />
          Quiz
          <span className="ml-1 rounded-full bg-slate-200 dark:bg-slate-600 px-2 py-0.5 text-xs font-semibold text-slate-600 dark:text-slate-300">
            {content.quiz.length}
          </span>
        </button>
      </div>

      {/* Content */}
      <div className="min-h-[400px]">
        {tab === "flashcards" ? (
          <FlashcardViewer cards={content.flashcards} />
        ) : (
          <QuizViewer key={quizKey} questions={content.quiz} onRestart={handleQuizRestart} />
        )}
      </div>
    </div>
  );
}
