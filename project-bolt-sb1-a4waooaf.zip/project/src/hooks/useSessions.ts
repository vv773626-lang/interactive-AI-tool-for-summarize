import { useCallback, useEffect, useState } from "react";
import { loadSessions, deleteSession, type SavedSession } from "@/lib/supabase";
import type { StudyContent } from "@/lib/types";

export function useSessions() {
  const [sessions, setSessions] = useState<SavedSession[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    setLoading(true);
    const data = await loadSessions();
    setSessions(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const remove = useCallback(async (id: string) => {
    const ok = await deleteSession(id);
    if (ok) {
      setSessions((prev) => prev.filter((s) => s.id !== id));
    }
    return ok;
  }, []);

  const loadFromSession = useCallback((session: SavedSession): { content: StudyContent; sessionId: string } => {
    return { content: session.content, sessionId: session.id };
  }, []);

  return { sessions, loading, refresh, remove, loadFromSession };
}
