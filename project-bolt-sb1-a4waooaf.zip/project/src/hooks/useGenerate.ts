import { useCallback, useEffect, useRef, useState } from "react";
import { generateStudySet, GenerateError } from "@/lib/api";
import type { StudyContent } from "@/lib/types";

type Status = "idle" | "loading" | "success" | "error";

interface GenerateState {
  status: Status;
  content: StudyContent | null;
  sessionId: string | null;
  error: string | null;
}

export function useGenerate() {
  const [state, setState] = useState<GenerateState>({
    status: "idle",
    content: null,
    sessionId: null,
    error: null,
  });

  // Track the latest request so a stale response can't overwrite a newer one
  const requestIdRef = useRef(0);
  const abortRef = useRef<AbortController | null>(null);

  const generate = useCallback(async (topic: string) => {
    // Abort any in-flight request
    if (abortRef.current) {
      abortRef.current.abort();
    }

    const controller = new AbortController();
    abortRef.current = controller;
    const requestId = ++requestIdRef.current;

    setState({
      status: "loading",
      content: null,
      sessionId: null,
      error: null,
    });

    try {
      const result = await generateStudySet(topic, { signal: controller.signal });

      // Only accept this response if it's still the latest request
      if (requestId !== requestIdRef.current) return;

      setState({
        status: "success",
        content: result.content,
        sessionId: result.sessionId ?? null,
        error: null,
      });
    } catch (err) {
      // Aborted — don't update state (a newer request is in flight)
      if (err instanceof GenerateError && !err.retryable && err.message.includes("cancelled")) {
        return;
      }

      if (requestId !== requestIdRef.current) return;

      const message = err instanceof GenerateError ? err.message : "Something went wrong. Please try again.";
      setState({
        status: "error",
        content: null,
        sessionId: null,
        error: message,
      });
    }
  }, []);

  const cancel = useCallback(() => {
    if (abortRef.current) {
      abortRef.current.abort();
      abortRef.current = null;
    }
    requestIdRef.current++;
    setState({
      status: "idle",
      content: null,
      sessionId: null,
      error: null,
    });
  }, []);

  // Load existing content (e.g. from a saved session)
  const loadContent = useCallback((content: StudyContent, sessionId: string | null) => {
    if (abortRef.current) {
      abortRef.current.abort();
    }
    requestIdRef.current++;
    setState({
      status: "success",
      content,
      sessionId,
      error: null,
    });
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (abortRef.current) {
        abortRef.current.abort();
      }
    };
  }, []);

  return { ...state, generate, cancel, loadContent };
}
