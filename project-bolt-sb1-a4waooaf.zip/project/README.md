# StudyForge — AI-Powered Study Assistant

Turn any topic or set of notes into interactive flashcards and a quiz. Paste your notes, let AI generate structured study content, then flip through cards and test yourself — with a re-test loop for wrong answers.

## Features

- **Free-form text input** — paste notes, describe a topic, or pick an example
- **AI-generated flashcards** — 3D flip animation, mark-as-known tracking, keyboard navigation
- **AI-generated quiz** — multiple choice with immediate feedback, explanations, and a scored results screen
- **Re-test wrong answers** — after the quiz, retry only the questions you got wrong
- **Session history** — study sets are saved automatically and can be revisited or deleted
- **Dark mode** — auto-detects system preference, toggle in the header
- **Fully responsive** — works from mobile to desktop
- **Robust failure handling** — see below

## Setup

```bash
npm install
npm run dev
```

The app requires a Supabase project with:
1. A `study_sessions` table (migration is applied automatically via Supabase MCP)
2. A deployed edge function at `supabase/functions/generate/`

No API key is needed — the app uses [Pollinations AI](https://pollinations.ai), a free LLM API that requires no authentication or API key.

Environment variables (pre-populated in `.env`):
- `VITE_SUPABASE_URL` — your Supabase project URL
- `VITE_SUPABASE_ANON_KEY` — your Supabase anon key

### Build

```bash
npm run build
npm run preview
```

## How it works

1. User enters a topic or notes in the text area
2. The frontend sends a POST request to the Supabase edge function `/functions/v1/generate`
3. The edge function calls the free Pollinations AI LLM API with a system prompt requesting structured JSON (flashcards + quiz)
4. The server validates the AI's output shape — if it's malformed, it retries up to 3 times automatically
5. Validated content is saved to the `study_sessions` table and returned to the frontend
6. The frontend validates the response again (defense in depth) and renders interactive components

## Handling bad AI output

This is the core challenge the app solves. Here's what it handles:

- **Malformed JSON** — the edge function strips markdown code fences and extracts JSON from surrounding text; the client validates the parsed shape
- **Wrong shape** — both server and client check for required fields (`title`, `flashcards`, `quiz`), correct types, array lengths, option counts, and `correctIndex` bounds
- **Empty output** — flashcards/quiz arrays must be non-empty; empty arrays trigger a retry
- **Slow responses** — the UI shows an animated loading state with status messaging
- **Failed requests** — network errors surface a user-friendly message with a retry button
- **Stale responses** — each request gets an incrementing ID; if a newer request is in flight when an older one resolves, the stale response is discarded (via `AbortController` + request ID tracking)
- **Server-side retry** — the edge function retries up to 3 times before returning an error, so transient bad output is often fixed transparently

### Error states

- **Inline form errors** — dismissible error banner below the input
- **Full error view** — retry button + "start over" when the AI fails after all server-side retries
- **Loading state** — animated indicator with explanatory text

## Tech stack

- **React 18** with hooks and functional components
- **TypeScript** for type safety
- **Vite** as the build tool
- **Tailwind CSS** for styling
- **Supabase** — database, edge functions, and session persistence
- **Pollinations AI** (free, no API key required) — LLM via OpenAI-compatible endpoint
- **lucide-react** for icons

## Architecture

```
src/
  components/
    InputForm.tsx        — free-form text input with examples
    LoadingState.tsx     — animated loading indicator
    ErrorState.tsx       — error display with retry
    FlashcardViewer.tsx  — 3D flip cards with known-tracking
    QuizViewer.tsx       — quiz player with feedback + re-test
    StudyView.tsx        — tabbed container for cards/quiz
    SessionHistory.tsx   — saved study sets sidebar
  hooks/
    useGenerate.ts       — generation state, abort, stale-response guard
    useSessions.ts       — session CRUD from Supabase
    useTheme.ts          — dark mode toggle
  lib/
    api.ts               — fetch wrapper + client-side validation
    supabase.ts          — Supabase client + session queries
    types.ts             — shared TypeScript interfaces
supabase/
  functions/generate/    — edge function: LLM proxy + validation + retry
  config.toml            — edge function config
```

## AI usage note

AI tools (Claude) were used to assist with:
- Scaffolding component structure and boilerplate
- Writing the LLM API integration and edge function
- Drafting the error-handling logic for malformed AI output
- Generating CSS/Tailwind styling

All code was reviewed, understood, and adjusted by the developer. The architecture decisions (stale request guarding, dual-side validation, re-test loop) were deliberate design choices.

## Known limitations

- **No streaming** — the full response is generated before rendering (streaming would improve perceived latency)
- **No refinement** — you can't ask the AI to tweak an existing study set; you regenerate from scratch
- **Fixed output size** — always 6 flashcards and 5 quiz questions (configurable in the edge function prompt)
- **Single language** — prompts are in English; non-English input may produce inconsistent results
- **No authentication** — sessions are shared (single-tenant). Anyone with the URL can see all study sets
- **Rate limits** — the free Pollinations API may rate-limit or queue requests under heavy load

## Time spent

Approximately 6 hours:
- ~1h: planning, edge function, database schema
- ~2h: frontend components (flashcards, quiz, study view)
- ~1h: failure handling and validation logic
- ~1h: styling, dark mode, responsive design, keyboard navigation
- ~1h: session persistence, README, build verification

## License

MIT
