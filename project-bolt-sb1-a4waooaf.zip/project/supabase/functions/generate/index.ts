import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const LLM_URL = "https://text.pollinations.ai/openai";

const SYSTEM_PROMPT = `You are a study assistant that creates flashcards and quizzes from user-provided notes or topics.

You MUST respond with ONLY a valid JSON object — no markdown, no code fences, no commentary before or after.

The JSON object must have this exact shape:
{
  "title": "a short descriptive title for this study set (max 60 chars)",
  "flashcards": [
    {
      "id": "fc-1",
      "front": "a question or term (max 200 chars)",
      "back": "the answer or definition (max 400 chars)"
    }
  ],
  "quiz": [
    {
      "id": "q-1",
      "question": "a multiple-choice question (max 300 chars)",
      "options": ["option A", "option B", "option C", "option D"],
      "correctIndex": 0,
      "explanation": "a short explanation of why the answer is correct (max 300 chars)"
    }
  ]
}

Rules:
- Generate exactly 6 flashcards and 5 quiz questions.
- Each flashcard id must be unique (e.g. "fc-1", "fc-2", ...).
- Each quiz id must be unique (e.g. "q-1", "q-2", ...).
- Each quiz question must have exactly 4 options.
- correctIndex must be an integer from 0 to 3.
- All text must be clear and educational.
- Do not include any text outside the JSON object.`;

interface Flashcard {
  id: string;
  front: string;
  back: string;
}

interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

interface StudyContent {
  title: string;
  flashcards: Flashcard[];
  quiz: QuizQuestion[];
}

function validateContent(data: unknown): { valid: boolean; content?: StudyContent; error?: string } {
  if (typeof data !== "object" || data === null) {
    return { valid: false, error: "Response is not a JSON object" };
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== "string" || obj.title.trim().length === 0) {
    return { valid: false, error: "Missing or invalid 'title'" };
  }

  if (!Array.isArray(obj.flashcards)) {
    return { valid: false, error: "Missing or invalid 'flashcards' array" };
  }

  if (!Array.isArray(obj.quiz)) {
    return { valid: false, error: "Missing or invalid 'quiz' array" };
  }

  if (obj.flashcards.length === 0) {
    return { valid: false, error: "'flashcards' array is empty" };
  }

  if (obj.quiz.length === 0) {
    return { valid: false, error: "'quiz' array is empty" };
  }

  for (let i = 0; i < obj.flashcards.length; i++) {
    const fc = obj.flashcards[i] as Record<string, unknown>;
    if (!fc || typeof fc.front !== "string" || typeof fc.back !== "string") {
      return { valid: false, error: `Flashcard ${i + 1} has invalid front/back` };
    }
  }

  for (let i = 0; i < obj.quiz.length; i++) {
    const q = obj.quiz[i] as Record<string, unknown>;
    if (!q || typeof q.question !== "string") {
      return { valid: false, error: `Quiz question ${i + 1} is invalid` };
    }
    if (!Array.isArray(q.options) || q.options.length !== 4) {
      return { valid: false, error: `Quiz question ${i + 1} must have exactly 4 options` };
    }
    if (!q.options.every((o) => typeof o === "string")) {
      return { valid: false, error: `Quiz question ${i + 1} options must all be strings` };
    }
    if (typeof q.correctIndex !== "number" || q.correctIndex < 0 || q.correctIndex > 3) {
      return { valid: false, error: `Quiz question ${i + 1} has invalid correctIndex` };
    }
    if (typeof q.explanation !== "string") {
      q.explanation = "";
    }
  }

  const content: StudyContent = {
    title: (obj.title as string).slice(0, 60),
    flashcards: (obj.flashcards as Flashcard[]).map((fc, i) => ({
      id: (fc.id as string) || `fc-${i + 1}`,
      front: fc.front,
      back: fc.back,
    })),
    quiz: (obj.quiz as QuizQuestion[]).map((q, i) => ({
      id: (q.id as string) || `q-${i + 1}`,
      question: q.question,
      options: q.options,
      correctIndex: q.correctIndex,
      explanation: q.explanation || "",
    })),
  };

  return { valid: true, content };
}

function extractJson(text: string): unknown | null {
  let cleaned = text.trim();

  // Remove ```json ... ``` or ``` ... ``` wrappers
  const fenceMatch = cleaned.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fenceMatch) {
    cleaned = fenceMatch[1].trim();
  }

  // Try direct parse first
  try {
    return JSON.parse(cleaned);
  } catch {
    // Fall through to extraction
  }

  // Find the first { and last } — extract the outermost JSON object
  const firstBrace = cleaned.indexOf("{");
  const lastBrace = cleaned.lastIndexOf("}");
  if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
    const candidate = cleaned.slice(firstBrace, lastBrace + 1);
    try {
      return JSON.parse(candidate);
    } catch {
      // Fall through
    }
  }

  return null;
}

async function callLLM(topic: string): Promise<unknown> {
  const response = await fetch(LLM_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "openai",
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: topic },
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`LLM API error (${response.status}): ${errorText.slice(0, 200)}`);
  }

  const data = await response.json();

  const choices = data?.choices;
  if (!Array.isArray(choices) || choices.length === 0) {
    throw new Error("LLM returned no choices");
  }

  const content = choices[0]?.message?.content;
  if (typeof content !== "string" || content.trim().length === 0) {
    throw new Error("LLM returned empty content");
  }

  const parsed = extractJson(content);
  if (parsed === null) {
    throw new Error("Could not extract valid JSON from LLM response");
  }

  return parsed;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }

  try {
    const body = await req.json();
    const topic = typeof body?.topic === "string" ? body.topic.trim() : "";

    if (topic.length === 0) {
      return new Response(
        JSON.stringify({ error: "Topic is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    if (topic.length > 5000) {
      return new Response(
        JSON.stringify({ error: "Topic is too long (max 5000 characters)" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // Try up to 3 times to get valid structured output
    let lastError = "";
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        const raw = await callLLM(topic);
        const result = validateContent(raw);
        if (result.valid && result.content) {
          // Save to database
          const supabaseUrl = Deno.env.get("SUPABASE_URL");
          const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

          let sessionId: string | undefined;
          if (supabaseUrl && serviceKey) {
            const supabase = createClient(supabaseUrl, serviceKey);
            const { data, error } = await supabase
              .from("study_sessions")
              .insert({ topic, content: result.content })
              .select("id")
              .single();
            if (!error && data) {
              sessionId = data.id;
            }
          }

          return new Response(
            JSON.stringify({ content: result.content, sessionId }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } },
          );
        }
        lastError = result.error || "Validation failed";
      } catch (err) {
        lastError = err instanceof Error ? err.message : String(err);
      }
    }

    return new Response(
      JSON.stringify({ error: `AI returned invalid output after 3 attempts: ${lastError}` }),
      { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : "Internal server error";
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
